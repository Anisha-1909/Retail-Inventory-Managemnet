from fastapi import FastAPI
from pydantic import BaseModel
from app.session_manager import SessionManager

app = FastAPI()

class LoginRequest(BaseModel):
    username: str
    password: str

class ConnectRequest(BaseModel):
    profile_url: str

class CheckMessageRequest(BaseModel):
    profile_url: str
    message: str

@app.post("/login")
def login(data: LoginRequest):
    bot = SessionManager.get_bot()
    bot.login(data.username, data.password)
    return {"status": "Logged in"}

@app.post("/connect")
def connect(data: ConnectRequest):
    bot = SessionManager.get_bot()
    bot.connect_to_profile(data.profile_url)
    return {"status": "Connection sent"}

@app.post("/check_connection")
def check(data: CheckMessageRequest):
    bot = SessionManager.get_bot()
    bot.check_connection_and_message(data.profile_url, data.message)
    return {"status": "Checked & messaged if connected"}

@app.get("/close")
def close():
    SessionManager.close_bot()
    return {"status": "Browser closed"}