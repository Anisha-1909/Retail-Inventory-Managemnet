import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class LinkedInBot:
    def __init__(self):
        options = uc.ChromeOptions()
        options.add_argument("--disable-blink-features=AutomationControlled")
        self.driver = uc.Chrome(options=options)

    def login(self, username, password):
        self.driver.get("https://www.linkedin.com/login")
        WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.ID, "username"))).send_keys(username)
        self.driver.find_element(By.ID, "password").send_keys(password)
        self.driver.find_element(By.XPATH, "//button[@type='submit']").click()

    def connect_to_profile(self, profile_url):
        self.driver.get(profile_url)
        try:
            connect_button = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label, 'Connect')]"))
            )
            connect_button.click()
            send_button = WebDriverWait(self.driver, 5).until(
                EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Send now']"))
            )
            send_button.click()
        except:
            pass

    def check_connection_and_message(self, profile_url, message):
        self.driver.get(profile_url)
        try:
            message_button = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(@aria-label, 'Message')]"))
            )
            message_button.click()
            text_area = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.TAG_NAME, "textarea"))
            )
            text_area.send_keys(message)
            send_button = self.driver.find_element(By.XPATH, "//button[@type='submit']")
            send_button.click()
        except:
            pass

    def close(self):
        self.driver.quit()