from app.linkedin_bot import LinkedInBot

class SessionManager:
    _bot = None

    @classmethod
    def get_bot(cls):
        if cls._bot is None:
            cls._bot = LinkedInBot()
        return cls._bot

    @classmethod
    def close_bot(cls):
        if cls._bot:
            cls._bot.close()
            cls._bot = None