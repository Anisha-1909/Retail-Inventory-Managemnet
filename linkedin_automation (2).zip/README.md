# LinkedIn Automation API

## Setup
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## API Endpoints

### POST /login
```json
{
  "username": "your_email",
  "password": "your_password"
}
```

### POST /connect
```json
{
  "profile_url": "https://www.linkedin.com/in/example/"
}
```

### POST /check_connection
```json
{
  "profile_url": "https://www.linkedin.com/in/example/",
  "message": "Hi! Looking forward to connecting with you."
}
```

### GET /close
Closes the browser session.
